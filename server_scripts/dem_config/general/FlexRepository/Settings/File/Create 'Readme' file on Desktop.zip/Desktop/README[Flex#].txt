Hello Contestant [Flex#%username%],

You are logged on to [Flex#%computername%].

This text file has been created by VMware DEM for demo purposes.
This specific setting can be found in the VMware DEM Management Console by going to the
'User Environment' ribbon tab and clicking on the 'Files and Folders' node in the left pane.

With this feature you can create files and folders in any location of the user profile.
For text files (including .INI files) you can also use placeholders to personalize the
file contents.
